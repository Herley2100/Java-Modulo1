/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Daniela
 */
public class Pronostico {
    private int numeroAñosAnteriores;
    private int sumaTotalAños;
    private double sumaTotalVentas;
    private int añosAlCuadrado;
    private double ventasAlCuadrado;
    private double añoxVenta;

    public Pronostico() {
        this.sumaTotalAños = 0;
        this.sumaTotalVentas = 0;
        this.añosAlCuadrado = 0;
        this.ventasAlCuadrado = 0;
        this.añoxVenta = 0;
        
    }

    public Pronostico(int numeroAñosAnteriores) {
        this.numeroAñosAnteriores = numeroAñosAnteriores;
        this.sumaTotalAños = 0;
        this.sumaTotalVentas = 0;
        this.añosAlCuadrado = 0;
        this.ventasAlCuadrado = 0;
        this.añoxVenta = 0;
    }
    
    

    public int getSumaTotalAños() {
        return sumaTotalAños;
    }

    public double getSumaTotalVentas() {
        return sumaTotalVentas;
    }

    public int getAñosAlCuadrado() {
        return añosAlCuadrado;
    }

    public double getVentasAlCuadrado() {
        return ventasAlCuadrado;
    }

    public double getAñoxVenta() {
        return añoxVenta;
    }
    
    public void calcularTotales (Año unAño){
        this.sumaTotalAños = this.sumaTotalAños + (unAño.getNumero());
        this.sumaTotalVentas = this.sumaTotalVentas + (unAño.getCantidadVentas());
    }
    
    public void calcularTotalVentasxAños(Año unAño){
        this.añoxVenta = this.añoxVenta + (unAño.getNumero() * unAño.getCantidadVentas());
    }
    
    public void calcularCuadrados(Año unAño){
        this.añosAlCuadrado = this.añosAlCuadrado + (int) Math.pow(unAño.getNumero(), 2);
        this.ventasAlCuadrado = this.ventasAlCuadrado + (int) Math.pow(unAño.getCantidadVentas(), 2);
    }
    
    
    public double calcularPronostico (int periodo){
        double a;
        double b;
        b = ((numeroAñosAnteriores * añoxVenta) - (sumaTotalAños * sumaTotalVentas)) /  ((numeroAñosAnteriores * añosAlCuadrado) - Math.pow(sumaTotalAños, 2)); 
        a = (sumaTotalVentas - b*sumaTotalAños) / numeroAñosAnteriores;
        
        
        return a + b*(periodo);
    }
    
    
    
    
    
    
}
