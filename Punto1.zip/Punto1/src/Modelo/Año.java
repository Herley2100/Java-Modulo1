/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Daniela
 */
public class Año {
    private int numero;
    private double cantidadVentas;

    public Año() {
        this.numero = 0;
        this.cantidadVentas = 0;
    }

    public Año(int numero, double cantidadVentas) {
        this.numero = numero;
        this.cantidadVentas = cantidadVentas;
    }
    
    public int getNumero() {
        return numero;
    }

    public double getCantidadVentas() {
        return cantidadVentas;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setCantidadVentas(double cantidadVentas) {
        this.cantidadVentas = cantidadVentas;
    }
    
    
    
    
    
    
}
