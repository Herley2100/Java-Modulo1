/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package punto1;

import Modelo.Año;
import Modelo.Pronostico;

/**
 *
 * @author Daniela
 */
public class Compañia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Pronostico unPronostico = new Pronostico(5);
        
        Año primerAño = new Año(1, 220);
        unPronostico.calcularCuadrados(primerAño);
        unPronostico.calcularTotalVentasxAños(primerAño);
        unPronostico.calcularTotales(primerAño);
        
        Año segundoAño = new Año(2, 245);
        unPronostico.calcularCuadrados(segundoAño);
        unPronostico.calcularTotalVentasxAños(segundoAño);
        unPronostico.calcularTotales(segundoAño);
        
        Año tercerAño = new Año(3, 250);
        unPronostico.calcularCuadrados(tercerAño);
        unPronostico.calcularTotalVentasxAños(tercerAño);
        unPronostico.calcularTotales(tercerAño);
        
        Año cuartoAño = new Año(4, 258);
        unPronostico.calcularCuadrados(cuartoAño);
        unPronostico.calcularTotalVentasxAños(cuartoAño);
        unPronostico.calcularTotales(cuartoAño);
        
        Año quintoAño = new Año(5, 273.5);
        unPronostico.calcularCuadrados(quintoAño);
        unPronostico.calcularTotalVentasxAños(quintoAño);
        unPronostico.calcularTotales(quintoAño);
        
        System.out.println("El pronostico de venta para los siguientes 5 años son: ");
        System.out.println("El pronostico de venta para el año 6 es: " + unPronostico.calcularPronostico(6));
        System.out.println("El pronostico de venta para el año 7 es: " + unPronostico.calcularPronostico(7));
        System.out.println("El pronostico de venta para el año 8 es: " + unPronostico.calcularPronostico(8));
        System.out.println("El pronostico de venta para el año 9 es: " + unPronostico.calcularPronostico(9));
        System.out.println("El pronostico de venta para el año 10 es: " + unPronostico.calcularPronostico(10));
        System.out.println("\n(Utilizamos los mismos valores del ejemplo en el pdf)");

    }
    
}
