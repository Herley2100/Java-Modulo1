/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Daniela
 */
public class DeclaracionOperadores {
        public static void main(String args[]){
            int a = 5;
            int b;
            b = 7;
            
            int c = a + b;
            
            c++;
            
            System.out.println(c);
       
    }
}
