/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Daniela
 */
public class Variables {
        public static void main(String args[]){
            //Creacion de las variables en el ejercicio del Video 6
            String nombre = "Ana";
            short edad = 27;
            float salario = (float) 1800.5;
            boolean carnet = true;
            
            //Imprimir los datos
            System.out.println(nombre);
            System.out.println(edad);
            System.out.println(salario);
            System.out.println(carnet);
 
    }
}
