/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Daniela
 */
public class Variables {
        public static void main(String args[]){
          int edad =35; //declaracion de variable Edad
                  
            System.out.println(edad);
            /*
            Se cambia el valor de la variable y se vuelve a imprimir en consola
            */
            
            edad = 75;
            System.out.println(edad);
    }
}
